import MenuLoginOrRegister from './MenuLoginOrRegister'

export default MenuLoginOrRegister
