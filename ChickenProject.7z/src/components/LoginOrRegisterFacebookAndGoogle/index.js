import LoginOrRegisterFacebookAndGoogle from './LoginOrRegisterFacebookAndGoogle'

export default LoginOrRegisterFacebookAndGoogle
