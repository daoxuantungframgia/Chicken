import ProductsContainer from './container/ProductsContainer'

export default {
  path: 'products',
  component: ProductsContainer,
}
