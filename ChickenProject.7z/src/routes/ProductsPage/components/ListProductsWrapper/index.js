import ListProductsWrapper from './ListProductsWrapper'

export default ListProductsWrapper
