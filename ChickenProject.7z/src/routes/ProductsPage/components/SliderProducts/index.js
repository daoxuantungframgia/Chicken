import SliderProducts from './SliderProducts'

export default SliderProducts
