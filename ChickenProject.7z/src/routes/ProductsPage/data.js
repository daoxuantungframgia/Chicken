import categoryImage1 from '../../assets/ga-mia-3-11_46.jpg'
import categoryImage2 from '../../assets/ga-mia-ong-tam_38.jpg'
import categoryImage3 from '../../assets/trung-ga-mia-ngon_50.jpg'
import categoryImage4 from '../../assets/giong-ga-mia_67.jpg'

const data1 = [
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
]

const data2 = [
  {
    image: categoryImage2,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage2,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage2,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage2,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage2,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
]

const data3 = [
  {
    image: categoryImage3,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage3,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage3,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage3,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage3,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
]

const data4 = [
  {
    image: categoryImage4,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage4,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage4,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage4,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage4,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
]

export {
  data1,
  data2,
  data3,
  data4,
}
