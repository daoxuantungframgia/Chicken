import Promotions from './Promotions'

export default Promotions
