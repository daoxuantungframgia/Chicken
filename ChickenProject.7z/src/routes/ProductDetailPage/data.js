import categoryImage1 from '../../assets/ga-mia-3-11_46.jpg'

export const data1 = [
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
]

export const productDetail = {
  image: categoryImage1,
  reducePercentage: 20,
  name: 'Gà mía tươi sạch',
  newAmount: '100,000',
  oldAmount: '120,000',
  description: 'Gà được làm sạch, tẩm ướp gia vị: hạt tiêu, hạt nêm, dầu hào, bột hạt điều, nước sốt ' +
    'nướng, dầu ăn và tất nhiên không thể thiếu được thứ quan trọng nhất - mật ong rừng. Khi tất cả..',
  detail: 'Gà được làm sạch, tẩm ướp gia vị: hạt tiêu, hạt nêm, dầu hào, bột hạt điều, nước sốt nướng, ' +
  'dầu ăn và tất nhiên không thể thiếu được thứ quan trọng nhất - mật ong rừng. Khi tất cả.. \n' +
  'Gà được làm sạch, tẩm ướp gia vị: hạt tiêu, hạt nêm, dầu hào, bột hạt điều, nước sốt nướng, dầu ăn ' +
  'và tất nhiên không thể thiếu được thứ quan trọng nhất - mật ong rừng. Khi tất cả những gia vị trên ' +
  'đã được ngấm đều, gà được kẹp vào thanh tre, nướng trên than hoa. Trong quá trình nướng, gà luôn ' +
  'được canh chừng để phết thêm mật ong lên da. Cứ vài lần như thế, thịt gà bên trong chín mềm nhưng ' +
  'không bở, da gà bên ngoài vàng ruộm, thơm lừng nhưng không hề bị cháy.'
}
