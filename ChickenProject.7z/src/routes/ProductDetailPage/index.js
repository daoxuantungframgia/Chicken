import ProductDetail from './container/ProductDetailContainer'

export default {
  path: 'products/:productId/:promotionId/:categoryId',
  component: ProductDetail
}
