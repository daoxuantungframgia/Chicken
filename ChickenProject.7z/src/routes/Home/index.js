import HomeContainer from './container/HomeContainer'

// Sync route definition
export default {
  component : HomeContainer
}
