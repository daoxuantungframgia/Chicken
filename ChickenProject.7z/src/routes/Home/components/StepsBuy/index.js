import StepsBuy from './StepsBuy'

export default StepsBuy
