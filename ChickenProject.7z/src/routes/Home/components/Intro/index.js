import Intro from './Intro'

export default Intro
