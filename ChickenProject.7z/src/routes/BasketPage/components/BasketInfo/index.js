import BasketInfo from './BasketInfo'

export default BasketInfo
