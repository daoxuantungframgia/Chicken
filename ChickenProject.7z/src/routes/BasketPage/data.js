import categoryImage1 from '../../assets/ga-mia-3-11_46.jpg'

export const data1 = [
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
  {
    image: categoryImage1,
    reducePercentage: 20,
    name: 'Gà mía tươi sạch',
    newAmount: '100,000',
    oldAmount: '120,000',
  },
]

export const basketInfo = {
  totalOldAmount: '10,000,000',
  totalDiscountAmount: '200,000',
  totalNewAmount: '80,000,000',
}
