import Basket from './container/BasketContainer'

export default {
  path: 'basket',
  component: Basket,
}
