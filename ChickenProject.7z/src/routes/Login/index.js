import Login from './container/Login'

export default {
  path: '/login',
  component: Login
}
