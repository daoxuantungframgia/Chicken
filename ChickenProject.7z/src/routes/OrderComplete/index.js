import OrderComplete from './components/OrderComplete'

export default {
  path: 'complete',
  component: OrderComplete
}
