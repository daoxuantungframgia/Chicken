import SelectAddress from './container/SelectAddress'

export default {
  path: 'select-address',
  component: SelectAddress
}
