export function validateRegisterForm (values) {
  const errors = {}

  if (!values.username) {
    errors.username = 'nhập tên đăng nhập đi'
  }

  return errors
}
