import Register from './container/Register'

export default {
  path: '/register',
  component: Register
}
